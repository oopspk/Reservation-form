<?php
/*
Plugin Name: Wp Reservation Form
Plugin URI: https://www.oops.pk/
Description: Simple Reservation
Author: www.oops.pk
Author URI: https://www.oops.pk/
Text Domain: Wp Reservation Form
Domain Path: /languages/
Version: 1.0.0
*/

defined('ABSPATH') || die ("You can't access this file directyly !");
define("wp_reservation_dir", __DIR__);
require(wp_reservation_dir."/oops_main_load.php");

register_activation_hook(__FILE__,'oops_wp_reservation_register_activation_hook');
register_deactivation_hook(__FILE__,'oops_wp_reservation_register_deactivation_hook');
register_uninstall_hook(__FILE__,'oops_wp_reservation_register_uninstall_hook');

function oops_wp_reservation_register_activation_hook(){

require(wp_reservation_dir."/inc/oops_wp_reservation_register_activation_hook.php");

}
function oops_wp_reservation_register_deactivation_hook(){

}
function oops_wp_reservation_register_uninstall_hook(){

}