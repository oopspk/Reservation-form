<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
	$get_option_label =  get_option( 'oops_wp_reservation_label_name' );
	$get_option_tag =  get_option( 'oops_wp_reservation_fields_tag' );
	$get_option_fields_type =  get_option( 'oops_wp_reservation_fields_type' );

?>
<div class="wrap">
	<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/images/logo_plugin.png';?>" class="plugin_logo_main">
<hr>
<div class="tabset">
  <!-- Tab 1 -->
  <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked>
  <label for="tab1">Customization</label>
  <!-- Tab 2 -->
  <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
  <label for="tab2">Add Options </label>
  <!-- Tab 3 -->
  <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
  <label for="tab3">Manage</label>
  
  <div class="tab-panels">
    <section id="marzen" class="tab-panel">
      <h2>Customization</h2>

      <div style="float: right; margin-bottom: 10px;">
      Shortcode: <input type="" name="" value="[oops_wp_reservation_form_shortcode]" style="width: 250px; height: 40px;">
 	 </div>
<?php require(wp_reservation_dir."/inc/oops_customization.php");?>

  </section>
    <section id="rauchbier" class="tab-panel">
      <h2>Add Options </h2>
<?php require(wp_reservation_dir."/inc/oops_add_options.php");?>

    </section>
    <section id="dunkles" class="tab-panel">
      <h2>Manage</h2>   
      
<?php require(wp_reservation_dir."/inc/oops_manage.php");?>

    </section>
  </div>
  
</div>
</div>