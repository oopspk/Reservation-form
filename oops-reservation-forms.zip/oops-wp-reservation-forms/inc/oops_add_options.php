<?php
defined('ABSPATH') || die ("You can't access this file directyly !");

?>