<?php
defined('ABSPATH') || die ("You can't access this file directyly !");

$rah ='register_activation_hook';

//Labels Names//
require(wp_reservation_dir."/inc/".$rah."/oops_wp_reservation_register_activation_hook_label.php");

//Fields Tags //
require(wp_reservation_dir."/inc/".$rah."/oops_wp_reservation_register_activation_hook_tags.php");

// Fields Types //
require(wp_reservation_dir."/inc/".$rah."/oops_wp_reservation_register_activation_hook_types.php");

?>