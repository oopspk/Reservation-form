<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
// create custom plugin settings menu
add_action('admin_menu', 'oops_wp_reservation_settings_menu');

function oops_wp_reservation_settings_menu() {

	//create new top-level menu
	add_menu_page('oops_wp_reservation_settings', 'Wp Reservation', 'administrator', __FILE__, 'register_oops_wp_reservation_settings_page' , '');

	//call register settings function
	add_action( 'admin_init', 'register_oops_wp_reservation_settings' );
}


function register_oops_wp_reservation_settings() {
	//register our settings
	register_setting( 'oops_wp_reservation_settings_group', 'new_option_name' );
	register_setting( 'oops_wp_reservation_settings_group', 'some_other_option' );
	register_setting( 'oops_wp_reservation_settings_group', 'option_etc' );
 
}
function register_oops_wp_reservation_settings_page() {

require(wp_reservation_dir."/inc/oops_main.php");

} 
?>
