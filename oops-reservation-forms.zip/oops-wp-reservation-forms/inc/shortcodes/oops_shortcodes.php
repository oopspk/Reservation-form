<?php
defined('ABSPATH') || die ("You can't access this file directyly !");

///*wp_reservation_form_shortcode*///

add_shortcode('oops_wp_reservation_form_shortcode', 'oops_wp_reservation_form_func' );
 
function oops_wp_reservation_form_func() {
 

   ob_start();

echo"hello";
 // return the buffer contents and delete
    return ob_get_clean();
     
}