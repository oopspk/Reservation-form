<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
?>
<form action ="#" method="POST" style="margin-top: 10px;">
      <table class="wp-list-table widefat fixed posts" style="margin-bottom:10px;">
	<thead>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</tfoot>
	<tbody>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
	</tbody>
</table>
	<input type="submit" name="customization_submit" id="submit" class="button button-primary" value="Save Changes">
</form>
