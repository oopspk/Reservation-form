<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
define("wp_reservation_dir", __DIR__);
require(wp_reservation_dir."/inc/functions.php");
require(wp_reservation_dir."/inc/shortcodes.php");
require(wp_reservation_dir."/inc/option_page.php");
