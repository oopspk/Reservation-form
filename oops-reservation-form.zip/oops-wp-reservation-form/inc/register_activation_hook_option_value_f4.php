<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
$option_name = 'oops_wp_reservation_option_value_f4';

 
if ( get_option( $option_name ) !== false ) {
 
 	$option_values =  get_option( 'oops_wp_reservation_option_value_f4' );
    update_option( $option_name, $option_values );
 
} else {
 
    // The option hasn't been created yet, so add it with $autoload set to 'no'.
    $new_value = array("f4"=>"pakistan", "f2"=>"india", "f3"=>"china", "f4"=>"afghanistan");
    $deprecated = null;
    $autoload = 'no';
    add_option( $option_name, $new_value, $deprecated, $autoload );
}
?>