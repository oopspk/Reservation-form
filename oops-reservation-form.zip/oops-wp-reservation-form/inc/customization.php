<?php 
defined('ABSPATH') || die ("You can't access this file directyly !");
?>
<form action ="#" method="POST" style="margin-top: 10px;">
      <table class="wp-list-table widefat fixed posts" style="margin-bottom:10px;">
	<thead>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</tfoot>
	<?php

		foreach ($get_option_label as $key=> $value) {
		
	?>
	<tbody>
		<tr>
			<td><?php echo  esc_attr(ucwords($value));?></td>
			<td>

<select name="optag[]">
<?php		
if($get_option_tag[$key] == 'Select'){
?>
<option>
<?php echo $get_option_tag[$key];?>
	
</option>

<option>Input</option>
<option>Textarea</option>

<?php					
}
if($get_option_tag[$key] == 'Input'){
?>
<option><?php echo $get_option_tag[$key];?></option>';
<option>Select</option>';
<option>Textarea</option>';
<?php
}
if($get_option_tag[$key] == 'Textarea'){
?>
<option><?php echo $get_option_tag[$key];?></option>';
<option>Select</option>';
<option>Input</option>';
<?php
}
?>
</select>

			</td>
			<td>
				<select name="optype[]">
				<?php
					if ($get_option_fields_type[$key] == 'Text') {
						echo'
							<option>'.$get_option_fields_type[$key].'</option>
							<option>Email</option>
							<option>Password</option>
						';
					}
					if ($get_option_fields_type[$key] == 'Email') {
						echo'
						<option>'.$get_option_fields_type[$key].'</option>
							<option>Text</option>
							
							<option>Password</option>
						';
					}
					if ($get_option_fields_type[$key] == 'Password') {
						echo'
							<option>Text</option>
							<option>Email</option>
							<option>'.$get_option_fields_type[$key].'</option>
						';
					}
				?>
				</select>	
			</td>
			<td>
				<input type="text" name="<?php echo $key;?>" value="<?php echo $get_option_label[$key];?>">
			</td>
		</tr>
	</tbody>

<?php
}
?>
</table>
	<input type="submit" name="customization_submit" id="submit" class="button button-primary" value="Save Changes">
</form>

<?php

if(isset($_POST['customization_submit'])){

$optag = array("f1"=>$_POST['optag'][0],"f2"=>$_POST['optag'][1], "f3"=>$_POST['optag'][2], "f4"=>$_POST['optag'][3]);


$option_name = 'oops_wp_reservation_fields_tag' ;
update_option( $option_name, $optag );
 

$optype = array("f1"=>$_POST['optype'][0], "f2"=>$_POST['optype'][1], "f3"=>$_POST['optype'][2], "f4"=>$_POST['optype'][3]);

$option_name = 'oops_wp_reservation_fields_type' ;
update_option( $option_name, $optype );

$op_label = array("f1"=>$_POST['f1'], "f2"=>$_POST['f2'], "f3"=>$_POST['f3'], "f4"=>$_POST['f4']);

$option_name = 'oops_wp_reservation_label_name' ;
update_option( $option_name, $op_label );





}
?>