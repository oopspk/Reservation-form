 <?php 
defined('ABSPATH') || die ("You can't access this file directyly !");

  $option_value_f1 =  get_option( 'oops_wp_reservation_option_value_f1' );
  $option_value_f2 =  get_option( 'oops_wp_reservation_option_value_f2' );
  $option_value_f3 =  get_option( 'oops_wp_reservation_option_value_f3' );
  $option_value_f4 =  get_option( 'oops_wp_reservation_option_value_f4' );



?>
<form action="" method="post">
<table style="width: 30%; " border="1" >
<tbody>
<tr>
<td style="width: 10%; padding: 10px;" >Options</td>
<td style="padding: 10px;">Email</td>
</tr>
<?php
if ($option_value_f1['stutus'] == 'select') {
  if($get_option_tag['f1'] == 'Select'){
foreach ($option_value_f1['f1'] as $key => $value) {
?>
<tr>
<td style="padding: 10px;"><?php echo esc_attr(ucwords($value));?></td>
<td style="padding: 10px;">
  <input type="text" name="emailf1[]">
</td>
</tr>
<?php
}
}
}
if ($option_value_f2['stutus'] == 'select') {
   if($get_option_tag['f2'] == 'Select'){
  foreach ($option_value_f2['f2'] as $key => $value) {
?>
<tr>
<td style="padding: 10px;"><?php echo esc_attr(ucwords($value));?></td>
<td style="padding: 10px;">
  <input type="text" name="emailf2[]">
</td>
</tr>
<?php
}
}
}
if ($option_value_f3['stutus'] == 'select') {
   if($get_option_tag['f3'] == 'Select'){



  foreach ($option_value_f3['f3'] as $key => $value) {

?>
 <tr>
<td style="padding: 10px;"><?php echo esc_attr(ucwords($value));?></td>
<td style="padding: 10px;">
  <input type="text" name="emailf3[]">
</td>
</tr>
<?php
}
}
}

if ($option_value_f4['stutus'] == 'select') {
   if($get_option_tag['f4'] == 'Select'){
  foreach ($option_value_f4['f4'] as $key => $value) {
?>
<tr>
<td style="padding: 10px;"><?php echo esc_attr(ucwords($value));?></td>
<td style="padding: 10px;">
  <input type="text" name="emailf4[]?>">
</td>
</tr>
<?php
}
}}


?>
</tbody>
</table>
<br>
  <input type="submit" name="manage_submit" id="submit" class="button button-primary" value="Save Changes">
</form>
<?php
if(isset($_POST['manage_submit'])){
  if(!empty($_POST['emailf1'][0])){
$option = array("f1"=>$_POST['emailf1']);
$option_name = 'oops_wp_reservation_option_emailf1';
update_option( $option_name, $option );


}
    if(!empty($_POST['emailf2'][0])){

$option = array("f2"=>$_POST['emailf2']);
$option_name = 'oops_wp_reservation_option_emailf2';
update_option( $option_name, $option );

  }
    if(!empty($_POST['emailf3'][0] )){



$option = array("f3"=>$_POST['emailf3']);
$option_name = 'oops_wp_reservation_option_emailf3';
update_option( $option_name, $option );


  }
    if(!empty($_POST['emailf4'][0])){

$option = array("f4"=>$_POST['emailf4']);
$option_name = 'oops_wp_reservation_option_emailf4';
update_option( $option_name, $option );
  }
}