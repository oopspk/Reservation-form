<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
$option_name = 'oops_wp_reservation_fields_tag';

 
if ( get_option( $option_name ) !== false ) {
 
 	$get_option_label =  get_option( 'oops_wp_reservation_fields_tag' );
    update_option( $option_name, $get_option_label );
 
} else {
 
    // The option hasn't been created yet, so add it with $autoload set to 'no'.
    $new_value = array("f1"=>"Input", "f2"=>"Select", "f3"=>"Textarea", "f4"=>"Textarea");
    $deprecated = null;
    $autoload = 'no';
    add_option( $option_name, $new_value, $deprecated, $autoload );
}
?>