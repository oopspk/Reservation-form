<?php
defined('ABSPATH') || die ("You can't access this file directyly !");

///*wp_reservation_form_shortcode*///

add_shortcode('oops_wp_reservation_form_shortcode', 'oops_wp_reservation_form_func' );
 
function oops_wp_reservation_form_func() {
  $get_option_label =  get_option( 'oops_wp_reservation_label_name' );
  $get_option_tag =  get_option( 'oops_wp_reservation_fields_tag' );
  $get_option_fields_type =  get_option( 'oops_wp_reservation_fields_type' );

  $option_value_f1 =  get_option( 'oops_wp_reservation_option_value_f1' );
  $option_value_f2 =  get_option( 'oops_wp_reservation_option_value_f2' );
  $option_value_f3 =  get_option( 'oops_wp_reservation_option_value_f3' );
  $option_value_f4 =  get_option( 'oops_wp_reservation_option_value_f4' );

  $oops_wp_emailf1 =  get_option( 'oops_wp_reservation_option_emailf1' );
  $oops_wp_emailf2 =  get_option( 'oops_wp_reservation_option_emailf2' );
  $oops_wp_emailf3 =  get_option( 'oops_wp_reservation_option_emailf3' );
  $oops_wp_emailf4 =  get_option( 'oops_wp_reservation_option_emailf4' );



ob_start();

?>
 <div class="container">
  <form action="#" method="post">
    <!-----------------------f1---------------------------->
    <?php
       
       if($get_option_tag['f1'] == 'Input'){
        $input_rq1 = $get_option_tag['f1'];
       
        echo' <div class="row">
      <div class="col-25">
        <label for="fname">'.esc_html($get_option_label['f1']).'</label>
      </div>
      <div class="col-75">
         <input type="text" id="lname" name="f1input" placeholder="'.$get_option_label['f1'].'">
      </div>
    </div>';
       }

if($get_option_tag['f1'] == 'Select'){
if ($option_value_f1['stutus'] == 'select') {
if($get_option_tag['f1'] == 'Select'){
  $input_rq1 = $get_option_tag['f1'];
echo '
 <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f1'].'</label>
      </div>
      <div class="col-75">
<select id="country" name="f1select">';
 echo'<option selected> None </option>';
foreach ($option_value_f1['f1'] as $key => $value) {
  echo'<option value="'.$key.'" >'.esc_attr(ucwords($value)).'</option>';
}
}
echo '</select></div></div>';
}
       }
       if($get_option_tag['f1'] == 'Textarea'){
        $input_rq1 = $get_option_tag['f1'];
        echo '   <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f1'].'</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="f1textarea" placeholder="'.$get_option_label['f1'].'" style="height:200px"></textarea>
      </div>
    </div>';
       }
    ?>
    <!-------------------------f1-------------------------->
    <!-----------------------f2---------------------------->
    <?php
       
       if($get_option_tag['f2'] == 'Input'){
        $input_rq2 = $get_option_tag['f2'];
        echo' <div class="row">
      <div class="col-25">
        <label for="fname">'.$get_option_label['f2'].'</label>
      </div>
      <div class="col-75">
         <input type="text" id="lname" name="f2input" placeholder="'.$get_option_label['f2'].'">
      </div>
    </div>';
       }
       if($get_option_tag['f2'] == 'Select'){
        $input_rq2 = $get_option_tag['f2'];
           if ($option_value_f2['stutus'] == 'select') {
  if($get_option_tag['f2'] == 'Select'){
  echo '
<div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f2'].'</label>
      </div>
      <div class="col-75">
  <select id="country" name="f2select">';
   echo'<option selected> None </option>';
foreach ($option_value_f2['f2'] as $key => $value) {
  echo'<option value="'.$key.'">'.esc_attr(ucwords($value)).'</option>';
}
}
echo '</select></div></div>';
}
       }
       if($get_option_tag['f2'] == 'Textarea'){
        $input_rq2 = $get_option_tag['f2'];
        echo '   <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f2'].'</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="f2textarea" placeholder="'.$get_option_label['f2'].'" style="height:200px"></textarea>
      </div>
    </div>';
       }
    ?>
    <!-------------------------f2-------------------------->
 <!-----------------------f3---------------------------->
    <?php
       
       if($get_option_tag['f3'] == 'Input'){
        $input_rq3 = $get_option_tag['f3'];
        echo' <div class="row">
      <div class="col-25">
        <label for="fname">'.$get_option_label['f3'].'</label>
      </div>
      <div class="col-75">
         <input type="text" id="lname" name="f3input" placeholder="Your last name..">
      </div>
    </div>';
       }
       if($get_option_tag['f3'] == 'Select'){
        $input_rq3 = $get_option_tag['f3'];
           if ($option_value_f3['stutus'] == 'select') {
  if($get_option_tag['f3'] == 'Select'){
  echo '
  <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f3'].'</label>
      </div>
      <div class="col-75">
  <select id="country" name="f3select">';
  echo'<option selected> None </option>';
foreach ($option_value_f3['f3'] as $key => $value) {
  echo'<option value="'.$key.'">'.esc_attr(ucwords($value)).'</option>';
}
}
echo '</select></div>
    </div>';
}
       }
       if($get_option_tag['f3'] == 'Textarea'){
        $input_rq3 = $get_option_tag['f3'];
        echo '<div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f3'].'</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="f3textarea" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>';
       }
    ?>
    <!-------------------------f3-------------------------->
     <!-----------------------f4---------------------------->
    <?php
       
       if($get_option_tag['f4'] == 'Input'){
        $input_rq4 = $get_option_tag['f4'];
        echo' <div class="row">
      <div class="col-25">
        <label for="fname">'.$get_option_label['f4'].'</label>
      </div>
      <div class="col-75">
         <input type="text" id="lname" name="f4input" placeholder="Your last name..">
      </div>
    </div>';
       }
       if($get_option_tag['f4'] == 'Select'){
        $input_rq4 = $get_option_tag['f4'];
           if ($option_value_f4['stutus'] == 'select') {
  if($get_option_tag['f4'] == 'Select'){
  echo '
  <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f4'].'</label>
      </div>
      <div class="col-75">
  <select id="country" name="f4select">';
   echo'<option selected> None </option>';
foreach ($option_value_f4['f4'] as $key => $value) {
  
  echo'<option value="'.$key.'">'.esc_attr(ucwords($value)).'</option>';
}
}
echo '</select></div>
    </div>';
}
       }
       if($get_option_tag['f4'] == 'Textarea'){
        $input_rq4 = $get_option_tag['f4'];
        echo '   <div class="row">
      <div class="col-25">
        <label for="subject">'.$get_option_label['f4'].'</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="f4textarea" placeholder="'.$get_option_label['f4'].'" style="height:200px"></textarea>
      </div>
    </div>';
       }
    ?>
    <!-------------------------f4-------------------------->
 
    <div class="row">
      <input type="submit" value="Submit" name="submit">
    </div>
  </form>
</div>     
<?php
if(isset($_POST['submit'])){

//******************f1**********************//
if($input_rq1 == 'Input'){
  if(empty($_POST['f1input'])){
    echo'<br>';
    echo''.$get_option_label['f1'].' is required';
    
  }
  else{
    $output_value1 = esc_attr(ucwords($_POST['f1input']));

  }
}
if($input_rq1 == 'Textarea'){
  if(empty($_POST['f1textarea'])){
    echo'<br>';
    echo''.$get_option_label['f1'].' is required';
    
  }
  else{
    $output_value1 = esc_attr(ucwords($_POST['f1textarea']));
  }
}
if($input_rq1 == 'Select'){
  if($_POST['f1select'] == 'None'){
    echo'<br>';
    echo''.$get_option_label['f1'].' is required';
  }
  else{
    $output_value1 = $_POST['f1select'];
  }
}
//******************f1*********************//
//******************f2**********************//
if($input_rq2 == 'Input'){
  if(empty($_POST['f2input'])){
    echo'<br>';
     echo''.$get_option_label['f2'].' is required';
  }
  else{
    $output_value2 = esc_attr(ucwords($_POST['f2input']));
  }
}
if($input_rq2 == 'Textarea'){
  if(empty($_POST['f2textarea'])){
    echo'<br>';
     echo''.$get_option_label['f2'].' is required';
  }
  else{
    $output_value2 = $_POST['f2textarea'];
  }
}
if($input_rq2 == 'Select'){
  if($_POST['f2select'] == 'None'){
    echo'<br>';
     echo''.$get_option_label['f2'].' is required';
  }
  else{
    $output_value2 = esc_attr(ucwords($_POST['f2select']));
  }
}
//******************f2*********************//
//******************f3**********************//
if($input_rq3 == 'Input'){
  if(empty($_POST['f3input'])){
    echo'<br>';
     echo''.$get_option_label['f3'].' is required';
  }
  else{
    $output_value3 = esc_attr(ucwords($_POST['f3input']));
  }
}
if($input_rq3 == 'Textarea'){
  if(empty($_POST['f3textarea'])){
    echo'<br>';
    echo''.$get_option_label['f3'].' is required';
  }
  else{
    $output_value3 = $_POST['f3textarea'];
  }
}
if($input_rq3 == 'Select'){
  if($_POST['f3select'] == 'None'){
    echo'<br>';
    echo''.$get_option_label['f3'].' is required';
  }
  else{
    $output_value3 = $_POST['f3select'];
  }
}
//******************f3*********************//
//******************f4**********************//
if($input_rq4 == 'Input'){
  if(empty($_POST['f4input'])){
    echo'<br>';
    echo''.$get_option_label['f4'].' is required';

  }
  else{
    $output_value4 = esc_attr(ucwords($_POST['f4input']));
  }
}
if($input_rq4 == 'Textarea'){
  if(empty($_POST['f4textarea'])){
    echo'<br>';
     echo''.$get_option_label['f4'].' is required';
  }
  else{
    $output_value4 = $_POST['f4textarea'];
  }
}
if($input_rq4 == 'Select'){
  if($_POST['f4select'] == 'None'){
    echo'<br>';
     echo''.$get_option_label['f4'].' is required';
  }
  else{
    $output_value4 = esc_attr(ucwords($_POST['f4select']));
  }
}
//******************f4*********************//
$output_value1; 
$output_value2; 
$output_value3; 
$output_value4;

    $subject = array (
  array("f1" => $output_value1),
  array("f2"=> $output_value2),
  array("f3"=>$output_value3),
  array("f4"=>$output_value4)
);

$output_value_array = array (
  array("output_value"=> $output_value1, "tag" => $get_option_tag['f1'],"fieldsnumber" => 'f1'),
  array("output_value"=> $output_value2, "tag" => $get_option_tag['f2'],"fieldsnumber" => 'f2'),
  array("output_value"=> $output_value3, "tag" => $get_option_tag['f3'],"fieldsnumber" => 'f3'),
  array("output_value"=> $output_value4, "tag" => $get_option_tag['f4'],"fieldsnumber" => 'f4'),
);

foreach ($output_value_array as $key => $output_value) {
  if($output_value['tag']=='Select'){
    if ($output_value['fieldsnumber'] == 'f1') {
      $output_value1array  = array($output_value1);
       $wp_email = $output_value1array[0];
       $toemail = $oops_wp_emailf1['f1'][$wp_email];

$to = ''.$toemail.'';
$sub = 'wpreservationform';

$body = $get_option_label['f1'].' : '.$subject[0]['f1'].'<br>'.$get_option_label['f2'].': '.$subject[1]['f2'].'<br>'.$get_option_label['f3'].' : '.$subject[2]['f3'].'<br>'.$get_option_label['f4'].' : '.$subject[3]['f4'];

$headers = array('Content-Type: text/html; charset=UTF-8');
$status = wp_mail( $to, $sub, $body, $headers );
if($status){
    echo "your success message sent ".$to."";
}



    }
    if ($output_value['fieldsnumber'] == 'f2') {
      $output_value2array  = array($output_value2);
       $wp_email = $output_value2array[0];
       $toemail = $oops_wp_emailf2['f2'][$wp_email];

       $to = ''.$toemail.'';
$sub = 'wpreservationform';

$body = $get_option_label['f1'].' : '.$subject[0]['f1'].'<br>'.$get_option_label['f2'].': '.$subject[1]['f2'].'<br>'.$get_option_label['f3'].' : '.$subject[2]['f3'].'<br>'.$get_option_label['f4'].' : '.$subject[3]['f4'];

$headers = array('Content-Type: text/html; charset=UTF-8');
$status = wp_mail( $to, $sub, $body, $headers );
if($status){
    echo "your success message sent ".$to."";
}


    }
    if ($output_value['fieldsnumber'] == 'f3') {
       $output_value3array  = array($output_value3);
       $wp_email = $output_value3array[0];
       $toemail = $oops_wp_emailf3['f3'][$wp_email];



$to = ''.$toemail.'';
$sub = 'wpreservationform';

$body = $get_option_label['f1'].' : '.$subject[0]['f1'].'<br>'.$get_option_label['f2'].': '.$subject[1]['f2'].'<br>'.$get_option_label['f3'].' : '.$subject[2]['f3'].'<br>'.$get_option_label['f4'].' : '.$subject[3]['f4'];

$headers = array('Content-Type: text/html; charset=UTF-8');
$status = wp_mail( $to, $sub, $body, $headers );
if($status){
    echo "your success message sent ".$to."";
}




    }
    if ($output_value['fieldsnumber'] == 'f4') {
      $output_value4array  = array($output_value4);
       $wp_email = $output_value4array[0];
       $toemail = $oops_wp_emailf4['f4'][$wp_email];
       $to = ''.$toemail.'';
$sub = 'wpreservationform';

$body = $get_option_label['f1'].' : '.$subject[0]['f1'].'<br>'.$get_option_label['f2'].': '.$subject[1]['f2'].'<br>'.$get_option_label['f3'].' : '.$subject[2]['f3'].'<br>'.$get_option_label['f4'].' : '.$subject[3]['f4'];

$headers = array('Content-Type: text/html; charset=UTF-8');
$status = wp_mail( $to, $sub, $body, $headers );
if($status){
    echo "your success message sent ".$to."";
}
    }
  }
}

 // return the buffer contents and delete
    return ob_get_clean();
     
  }}