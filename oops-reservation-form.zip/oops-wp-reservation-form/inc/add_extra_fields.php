<?php 
defined('ABSPATH') || die ("You can't access this file directyly !");
?>
<form action="" method="POST">
<?php

foreach ($get_option_tag as $key => $value):
    if($value == 'Select'):

?>
<table class="wp-list-table widefat fixed posts" style="margin-bottom:10px;">
	<thead>
		<tr>
			<th> Labels Names </th>
			<th> Options Values </th>
			<th> Add Options </th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th> Labels Names </th>
			<th> Options Values </th>
			<th> Add Options </th>
		</tr>
	</tfoot>
	<tbody>
		<tr>
			<td><?php echo esc_attr(ucwords($get_option_label[$key])) ?></td>
			<td>

<ol class="addoption<?php echo $key;?>" >
<li ><input type="text" name="add_option<?php echo $key;?>[]"></li>
</ol>
 </td>
			<td>
				<a class="btn<?php echo $key?>" id="<?php echo $key?>" onClick="reply_click(this.id)">Add Option</a>
			</td>
		</tr>
	</tbody>
</table>

<?php

endif;
endforeach;
?>
 <input type="submit" name="add_extra_fields" id="submit" class="button button-primary" value="Save Changes">


 </form>
 <?php

 if(isset($_POST['add_extra_fields'])){


if(!empty($_POST['add_optionf1'][0])){
$option = array("f1"=>$_POST['add_optionf1'],"stutus"=>'select');
$option_name = 'oops_wp_reservation_option_value_f1' ;
update_option( $option_name, $option );
}



if(!empty($_POST['add_optionf2'][0])){
$option = array("f2"=>$_POST['add_optionf2'],"stutus"=>'select');
$option_name = 'oops_wp_reservation_option_value_f2' ;
update_option( $option_name, $option );
}
if(!empty($_POST['add_optionf3'][0])){
$option = array("f3"=>$_POST['add_optionf3'],"stutus"=>'select');
$option_name = 'oops_wp_reservation_option_value_f3' ;
update_option( $option_name, $option );
}
if(!empty($_POST['add_optionf4'][0])){
$option = array("f4"=>$_POST['add_optionf4'],"stutus"=>'select');
$option_name = 'oops_wp_reservation_option_value_f4' ;
update_option( $option_name, $option );
}
}