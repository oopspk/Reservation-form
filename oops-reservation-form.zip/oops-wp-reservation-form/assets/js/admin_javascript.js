

 function reply_click(clicked_id)
  {
  	jQuery(function($){
    $(".addoption"+clicked_id+"").append('<li ><input type="text" name="add_option'+clicked_id+'[]"></li>');
  	});
  }






