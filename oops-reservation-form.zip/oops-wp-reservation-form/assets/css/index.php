<?php
//Silence Is Golden